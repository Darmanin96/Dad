package dad;

import java.io.*;

public class Darmanin_Daniel_ActPGV02A {
    public static void main(String[] args) {
        String os = System.getProperty("os.name").toLowerCase();
        String command;
        //Detectamos si el sistema operativo de nuestro equipo es Windows
        if (os.contains("win")) {
            command = "systeminfo";
            //Detectamos el sistema operativo de nuestro equipo si es Linux o Mac
        } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
            command = "uname -a";
        } else {
            //En caso de que el sistema operativo no sea uno de los anteriores nos saldrá este mensaje
            System.out.println("Sistema operativo no soportado.");
            return;
        }

        try {
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            StringBuilder output = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                output.append(line).append(System.lineSeparator());
            }
            
            process.waitFor();
            Guardar(output.toString());

            //Exención por si hay algún error a la hora de ejecutar el comando
        } catch (IOException | InterruptedException e) {
            System.out.println("Error al ejecutar el comando: " + e.getMessage());
        }
    }

    /*Crearemos una función llamada Guardar en la que crearemos un fichero llamado Sysinfo.txt en la cual
     guardaremos toda la información del comando systeminfo
    */
    public static void Guardar(String data) {
        try (FileWriter fileWriter = new FileWriter("Sysinfo.txt")) {
            fileWriter.write(data);
            System.out.println("Información guardada en Sysinfo.txt");
        } catch (IOException e) {
            //Error al guardar la información del comando sysinfo en el archivo
            System.out.println("Error al guardar en el archivo: " + e.getMessage());
        }
    }
}

